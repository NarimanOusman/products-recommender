import boto3
import urllib.parse

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Extract bucket and file info from the incoming S3 trigger event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    
    # We only care about new files landing inside raw-data/
    if not key.startswith('raw-data/') or key == 'raw-data/':
        return {'status': 'skipped', 'message': 'Not a file in raw-data/'}
        
    try:
        # Stream the first line of the file to check headers
        response = s3_client.get_object(Bucket=bucket, Key=key)
        first_line = response['Body'].iter_lines().__next__().decode('utf-8')
        column_count = len(first_line.split(','))
        
        print(f"File detected: {key} | Column count detected: {column_count}")
        
        # Validation Rule: Our catalog expects exactly 9 columns
        if column_count == 9:
            target_key = key.replace('raw-data/', 'processed-data/')
            
            # Move the file to processed-data/
            s3_client.copy_object(Bucket=bucket, CopySource={'Bucket': bucket, 'Key': key}, Key=target_key)
            s3_client.delete_object(Bucket=bucket, Key=key)
            
            print(f" Validation Passed! Moved {key} to {target_key}")
            return {'status': 'success', 'message': 'File validated and moved'}
        else:
            print(f" Validation Failed! File has {column_count} columns instead of 9.")
            return {'status': 'failed', 'message': 'Invalid column count'}
            
    except Exception as e:
        print(f"Error processing data tracking: {e}")
        raise e
